const { modul } = require("./module");
const { baileys, boom, chalk, fs, FileType, path, process, PhoneNumber } = modul;
const { Boom } = boom
const { default: makeWaSocket, useSingleFileAuthState, DisconnectReason, fetchLatestBaileysVersion, generateForwardMessageContent, generateWAMessage, prepareWAMessageMedia, generateWAMessageFromContent, generateMessageID, downloadContentFromMessage, makeInMemoryStore, jidDecode, proto } = baileys
const color = (text, color) => { return !color ? chalk.green(text) : chalk.keyword(color)(text) }
const log = (pino = require("pino"));
const qrcode = require("qrcode");
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./database/exif')
const { smsg } = require('./lib/myfunc')
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })

if (global.conns instanceof Array) console.log()
else global.conns = []

const jadibot = async (virgopush, msg, from) => {
const { sendImage, sendMessage } = virgopush;
const { reply, sender } = msg;
const { state } = useSingleFileAuthState(`./data/${from}.json`)

const connectToWhatsApp = () => {
const virgopush = makeWaSocket({ logger: pino ({ level: 'silent' }), printQRInTerminal: true, auth: state, browser: ["VIRGO BOTZ OFFICIAL", "Dekstop", "3.0"]})
console.log(color('[ 𝗖𝗢𝗡𝗡𝗘𝗖𝗧☑️ ]\n', 'red'),color('\nInfo Script :\n➸ Baileys : Multi Device\n➸ Nama Script : VirgoPushSave\n➸ Creator : Virgo Botzz\n\nThanks\n', 'red'))

store.bind(virgopush.ev)

virgopush.ev.on('messages.upsert', async chatUpdate => {
try {
m = chatUpdate.messages[0]
if (!m.message) return
m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
if (!virgopush.public && !m.key.fromMe && chatUpdate.type === 'notify') return
if (m.key.id.startsWith('BAE5') && m.key.id.length === 16) return
msg = smsg(virgopush, m, store)
require('./virgopushsave')(virgopush, msg, chatUpdate, store)
} catch (err) {
console.log(err)}})

virgopush.ev.on("connection.update", async up => {
const { lastDisconnect, connection } = up;
if (connection == "connecting") return
if (connection){
if (connection != "connecting") console.log("Connecting to jadibot..")
}
console.log(up)
if (up.qr) await sendImage(from, await qrcode.toDataURL(up.qr,{scale : 8}), 'Scan QR ini untuk jadi bot sementara\n\n1. Klik titik tiga di pojok kanan atas\n2. Ketuk WhatsApp Web\n3. Scan QR ini \nQR Expired dalam 30 detik', m)
console.log(connection)
if (connection == "open") {
virgopush.id = virgopush.decodeJid(virgopush.user.id)
virgopush.time = Date.now()
global.conns.push(virgopush)
user = `${virgopush.decodeJid(virgopush.user.id)}`
txt = `Terdeteksi User Jadibot\n\n User : @${user.split("@")[0]}`
sendMessage(`6285721627486@s.whatsapp.net`,{text: txt, mentions : [user]})
}
if (connection === 'close') {
lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut ? connectToWhatsApp() : ''
}
})

virgopush.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}

virgopush.ev.on('contacts.update', update => {
for (let contact of update) {
let id = virgopush.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
}
})

if (virgopush.user && virgopush.user.id) virgopush.user.jid = virgopush.decodeJid(virgopush.user.id)
virgopush.chats = {}
virgopush.contacts = {}

function updateNameToDb(contacts) {
        if (!contacts) return
        for (let contact of contacts) {
        let id = virgopush.decodeJid(contact.id)
        if (!id) continue
        let chats = virgopush.contacts[id]
        if (!chats) chats = { id }
        let chat = {
        ...chats,
        ...({
        ...contact, id, ...(id.endsWith('@g.us') ?
        { subject: contact.subject || chats.subject || '' } :
        { name: contact.notify || chats.name || chats.notify || '' })
        } || {})
        }
        virgopush.contacts[id] = chat
        }
}

virgopush.ev.on('contacts.upsert', updateNameToDb)
virgopush.ev.on('groups.update', updateNameToDb)

virgopush.saveName = async (id, name = '') => {
        if (!id) return
        id = virgopush.decodeJid(id)
        let isGroup = id.endsWith('@g.us')
        if (id in virgopush.contacts && virgopush.contacts[id][isGroup ? 'subject' : 'name'] && id in virgopush.chats) return
        let metadata = {}
        if (isGroup) metadata = await virgopush.groupMetadata(id)
        let chat = { ...(virgopush.contacts[id] || {}), id, ...(isGroup ? { subject: metadata.subject, desc: metadata.desc } : { name }) }
        virgopush.contacts[id] = chat
        virgopush.chats[id] = chat
}

virgopush.getName = (jid, withoutContact  = false) => {
id = virgopush.decodeJid(jid)
withoutContact = virgopush.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = virgopush.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === virgopush.decodeJid(virgopush.user.id) ?
virgopush.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
}

virgopush.public = true

virgopush.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
let type = await FileType.fromBuffer(buffer)
trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
await fs.writeFileSync(trueFileName, buffer)
return trueFileName
}

virgopush.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
return buffer
}

const { getImg } = require('./lib/functions')

virgopush.sendImage = async (jid, path, caption = '', quoted = '', options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await virgopush.sendMessage(jid, { image: buffer, caption: caption, ...options }, { quoted })
}

virgopush.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getImg(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)
}
await virgopush.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}

virgopush.sendButMessage = (jid, buttons = [], text, footer, quoted = '', options = {}) => {
let buttonMessage = {
text,
footer,
buttons,
headerType: 2,
...options
}
virgopush.sendMessage(jid, buttonMessage, { quoted, ...options })
}

}
connectToWhatsApp()
}

module.exports = { jadibot, conns }

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})