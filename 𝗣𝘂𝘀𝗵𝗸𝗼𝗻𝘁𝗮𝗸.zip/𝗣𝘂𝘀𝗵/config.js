const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["6285721627486@s.whatsapp.net"]
global.nomerOwner = "6285721627486"
global.nomorOwner = ['6285721627486']
global.namaDeveloper = "Yanz"
global.namaBot = "Virgo Botz"
global.packname = "Sticker By"
global.author = "Virgo Botz"
global.thumb = fs.readFileSync("./image/thumb.png")
global.jumhal = '1000000000'
global.doc1 =
 "application/vnd.openxmlformats-officedocument.presentationml.presentation";
global.doc2 =
 "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
global.doc3 =
 "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
global.doc4 = "application/zip";
global.doc5 = "application/pdf";
global.doc6 = "application/vnd.android.package-archive";

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})